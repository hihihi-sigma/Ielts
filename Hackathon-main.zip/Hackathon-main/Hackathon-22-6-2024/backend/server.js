const express = require('express');
const axios = require('axios');
const cors = require('cors');
require('dotenv').config();

const app = express();
const port = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

app.post('/api/generate-reading-material', async (req, res) => {
  const model = req.body.model || 'gpt-4-1106-preview';
  const { task, difficulty } = req.body; // Task and difficulty parameters sent from the client

  const generatePrompt = (task, difficulty) => {
    let prompt = '';

    switch(task){
      case 'task1':
        prompt = `start your reply with a paragraph.
          generate for me a paragraph for Ielts listening task 1 and questions about the paragraph.
          Type of Tasks: Typically involves a conversation between two speakers in a social or everyday context.
          Form completion (filling in blanks on a form or notes), short-answer questions related to factual details, matching tasks (matching information to speakers or categories).
          [your form with blank to fill in or the match table]
          if you generating a matching type or short-answer question
          [your question here]
          and I want that task 1 will have 10 question`;
        break;
      case 'task2':
        prompt = `start your reply with a paragraph
          generate for me Ielts listening task 2 Type of Task: Includes a monologue or dialogue related to everyday social situations or transactions.
          Map or plan labeling (labeling parts of a map, plan, or diagram based on the spoken description), multiple-choice questions about specific details mentioned in the recording.
          if you generate map or plan labeling
          [your map,plan labeling, diagram here]
          [your answer here]
          if you generate multiple choice 
          [your question here]
          [your answer here] 
          I want 10 question for task 2.`;
        break;
      case 'task3':
        prompt = `start your reply with a paragraph.
          generate for me Ielts listening task 3 Type of Task: Features a conversation among up to four speakers in an academic or educational context.
          Multiple-choice questions requiring understanding of opinions, attitudes, or main ideas discussed, form completion with more detailed academic information.
          if you generate form completion
          [your form with blank to fill in]
          if you generate multiple choice 
          [your question here]
          [your answer here]
          and I want 10 question for task 3`;
        break;
      case 'task4':
        prompt = `start your reply with a paragraph
          generate for me Ielts listening task 4 Type of Task: Presents a monologue on an academic subject, such as a lecture or talk by one speaker.
          Sentence completion (filling in gaps in sentences based on the lecture content), matching tasks requiring understanding of organization or structure of the lecture.
          if you generate sentence completion
          [your paragraph with blank to fill in]
          if you generate matching task 
          [your table here]
          [your answer match here]
          and I want 10 question for task 4`;
        break;
    }

    if (difficulty === 'Easy') {
      prompt = prompt.replace(/paragraph\./, 'paragraph. The paragraph should have around 70 words and the words should mostly be elementary level.');
    } else if (difficulty === 'Hard') {
      prompt = prompt.replace(/paragraph\./, 'paragraph. The paragraph should have around 300 words and the words should mostly be college level.');
    }

    return prompt;
  };

  try {
    const response = await axios.post('https://api.openai.com/v1/chat/completions', {
      model: model,
      messages: [{ role: 'system', content: generatePrompt(task, difficulty) }],
    }, {
      headers: {
        'Authorization': `Bearer ${process.env.YOUR_OPENAI_API_KEY}`
      }
    });

    const text = response.data.choices[0].message.content.trim();
    const [generatedParagraph, ...generatedQuestions] = text.split('\n').filter(line => line.trim() !== '');

    res.json({ paragraph: generatedParagraph, questions: generatedQuestions });
  } catch (error) {
    console.error('Error fetching reading material:', error);
    res.status(500).json({ error: 'Failed to fetch reading material' });
  }
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
