'use client';

import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import Header from '../components/Header';

const ReadingPage = () => {
  const [paragraph, setParagraph] = useState('');
  const [questions, setQuestions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [model, setModel] = useState('gpt-4-1106-preview');
  const [voices, setVoices] = useState([]);
  const [selectedVoice, setSelectedVoice] = useState(null);
  const [speechActive, setSpeechActive] = useState(false);
  const [currentChunkIndex, setCurrentChunkIndex] = useState(0);
  const [lastChunkIndex, setLastChunkIndex] = useState(0);
  const [speed, setSpeed] = useState(1.0);
  const [difficulty, setDifficulty] = useState('Easy');
  const utteranceRef = useRef(null);
  const chunksRef = useRef([]);

  useEffect(() => {
    const fetchVoices = () => {
      const availableVoices = window.speechSynthesis.getVoices();
      const englishVoices = availableVoices.filter(voice => voice.lang.startsWith('en'));
      setVoices(englishVoices);
    };

    fetchVoices();

    if (speechSynthesis.onvoiceschanged !== undefined) {
      speechSynthesis.onvoiceschanged = fetchVoices;
    }
  }, []);

  useEffect(() => {
    const speakParagraph = () => {
      if (!paragraph || !selectedVoice) return;

      const chunkSize = 200;
      const chunks = [];
      for (let i = 0; i < paragraph.length; i += chunkSize) {
        chunks.push(paragraph.substring(i, i + chunkSize));
      }
      chunksRef.current = chunks;

      const speakChunksSequentially = (index) => {
        if (index >= chunks.length) {
          setSpeechActive(false);
          setCurrentChunkIndex(0);
          return;
        }

        const utterance = new SpeechSynthesisUtterance(chunks[index]);
        utterance.voice = selectedVoice;
        utterance.lang = selectedVoice.lang;
        utterance.pitch = 1;
        utterance.rate = speed;
        utterance.volume = 1;

        utterance.onstart = () => {
          setCurrentChunkIndex(index);
        };

        utterance.onend = () => {
          setLastChunkIndex(index);
          if (speechActive) {
            speakChunksSequentially(index + 1);
          } else {
            setSpeechActive(false);  // Make sure speechActive is false when stopping
          }
        };

        if (speechActive && index >= lastChunkIndex) {
          window.speechSynthesis.speak(utterance);
        }

        utteranceRef.current = utterance;
      };

      setCurrentChunkIndex(lastChunkIndex);
      setSpeechActive(true);
      speakChunksSequentially(lastChunkIndex);
    };

    if (speechActive) {
      speakParagraph();
    }

  }, [paragraph, selectedVoice, speechActive, lastChunkIndex, speed]);

  const fetchReadingMaterial = async (task) => {
    setLoading(true);
    try {
      const response = await axios.post('http://localhost:5000/api/generate-reading-material', { model, task, difficulty });
      const { paragraph, questions } = response.data;
      setParagraph(paragraph);
      setQuestions(questions);
      setLoading(false);
      // Automatically start speaking once the paragraph is generated
      handleStopOrContinueSpeech();
    } catch (error) {
      console.error('Error fetching listening material:', error);
      setLoading(false);
    }
  };

  const handleSelectVoice = (event) => {
    const selectedVoiceName = event.target.value;
    const voice = voices.find(voice => voice.name === selectedVoiceName);

    if (speechActive) {
      stopSpeech();
    }

    setSelectedVoice(voice);
  };

  const handleStopOrContinueSpeech = () => {
    if (speechActive) {
      stopSpeech();
    } else {
      continueSpeech();
    }
  };

  const stopSpeech = () => {
    if (utteranceRef.current) {
      utteranceRef.current.onend = null;
      window.speechSynthesis.cancel();
    }
    setSpeechActive(false);
  };

  const continueSpeech = () => {
    if (lastChunkIndex < paragraph.length) {
      window.speechSynthesis.resume();
      setSpeechActive(true);
    }
  };

  const handleSpeedChange = (event) => {
    const newSpeed = parseFloat(event.target.value);
    setSpeed(newSpeed);
    if (speechActive) {
      stopSpeech();
      continueSpeech();
    }
  };

  const handleDifficultyChange = (event) => {
    setDifficulty(event.target.value);
  };

  useEffect(() => {
    const initialSpeech = new SpeechSynthesisUtterance('');
    window.speechSynthesis.speak(initialSpeech);
  }, []);

  return (
    <div className="flex flex-col">
      <Header />
      <div className="min-h-screen bg-gray-100 flex flex-col items-center py-10">
        <h1 className="text-3xl font-bold text-gray-800 mb-6">IELTS Listening Practice</h1>
        <div className="flex space-x-4">
          <button 
            onClick={() => fetchReadingMaterial('task1')} 
            disabled={loading} 
            className="bg-blue-500 text-white px-6 py-3 rounded-md shadow-md hover:bg-blue-600 transition duration-300 disabled:opacity-50"
          >
            {loading ? 'Generating...' : 'Task 1'}
          </button>
          <button 
            onClick={() => fetchReadingMaterial('task2')} 
            disabled={loading} 
            className="bg-blue-500 text-white px-6 py-3 rounded-md shadow-md hover:bg-blue-600 transition duration-300 disabled:opacity-50"
          >
            {loading ? 'Generating...' : 'Task 2'}
          </button>
          <button 
            onClick={() => fetchReadingMaterial('task3')} 
            disabled={loading} 
            className="bg-blue-500 text-white px-6 py-3 rounded-md shadow-md hover:bg-blue-600 transition duration-300 disabled:opacity-50"
          >
            {loading ? 'Generating...' : 'Task 3'}
          </button>
          <button 
            onClick={() => fetchReadingMaterial('task4')} 
            disabled={loading} 
            className="bg-blue-500 text-white px-6 py-3 rounded-md shadow-md hover:bg-blue-600 transition duration-300 disabled:opacity-50"
          >
            {loading ? 'Generating...' : 'Task 4'}
          </button>
        </div>
        <div className="mt-6">
          <h2 className="text-2xl font-semibold text-gray-800 mb-4">Select Voice</h2>
          <select onChange={handleSelectVoice} className="px-4 py-2 rounded bg-gray-300 text-black">
            <option value="">Select a voice</option>
            {voices.map((voice, index) => (
              <option key={index} value={voice.name}>
                {voice.name} ({voice.lang})
              </option>
            ))}
          </select>
        </div>

        <div className="mt-6">
          <label htmlFor="speed" className="text-xl font-semibold text-gray-800 mb-2 block">Adjust Speed:</label>
          <input 
            type="range" 
            id="speed" 
            name="speed" 
            min="0.5" 
            max="1.8" 
            step="0.1" 
            value={speed} 
            onChange={handleSpeedChange} 
            className="w-64"
          />
          <span className="text-gray-700 ml-2">{speed.toFixed(1)}x</span>
        </div>

        <div className="mt-6">
          <label htmlFor="difficulty" className="text-xl font-semibold text-gray-800 mb-2 block">Select Difficulty:</label>
          <select id="difficulty" name="difficulty" value={difficulty} onChange={handleDifficultyChange} className="px-4 py-2 rounded bg-gray-300 text-black">
            <option value="Easy">Easy</option>
            <option value="Medium">Medium</option>
            <option value="Hard">Hard</option>
          </select>
        </div>

        <div className="mt-6">
          <button 
            onClick={handleStopOrContinueSpeech} 
            disabled={loading} 
            className={`px-6 py-3 rounded-md shadow-md ${speechActive ? 'bg-red-500 text-white' : 'bg-green-500 text-white'} hover:bg-red-600 transition duration-300`}
          >
            {loading ? 'Generating...' : (speechActive ? 'Stop Speaking' : 'Continue Speaking')}
          </button>
        </div>

        {!speechActive && paragraph && (
          <div className="mt-10 max-w-3xl bg-white shadow-md rounded-lg p-6">
            <h2 className="text-2xl font-semibold text-gray-800 mb-4">Generated Paragraph</h2>
            <p className="text-gray-700">{paragraph}</p>
          </div>
        )}

        {questions.length > 0 && (
          <div className="mt-10 max-w-3xl bg-white shadow-md rounded-lg p-6">
            <h2 className="text-2xl font-semibold text-gray-800 mb-4">Questions</h2>
            {questions.map((question, index) => (
              <div key={index} className="mb-4">
                <p className="text-gray-700">{question}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default ReadingPage;
